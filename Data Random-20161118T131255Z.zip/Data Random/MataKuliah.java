import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class MataKuliah{
	
	static int amount = 40;
	
	static int kode = 0;
	static String[] namaMataKuliah = {"Dasar Dasar Pemrograman","Fisika Dasar 1","Matematika Diskret 1","SDA", "Matematika Dasar 1", "Basis Data", "Aljabar Linear", 
									  "Matematika Diskret 2","Administrasi Bisnis", "Fisika Dasar 2", "Pengantar Sistem Dijital","Statistika & Probabilitas",
									  "Perancangan & Pemrograman Web","Pengantar Organisasi Komputer","Matematika Dasar 2","Sistem Operasi","Teori Bahasa & Automata",
									  "Pemrograman Deklaratif","Rekayasa Perangkat Lunak","Pemrograman Sistem","Sistem Cerdas","Jaringan Komputer","Analisis Numerik",
									  "Desain & Analisis Algoritma","Proyek Perangkat Lunak","Kerja Praktik","Komputer & Masyarakat","Pemrograman Konkuren & Parallel",
									  "Organisasi Sistem Komputer","Embedded Systems","Teori Informasi","Teknik Kompilator","Kriptografi & Keamanan Informasi",
									  "Layanan & Aplikasi Web","Pengolahan Sinyal Dijital","Sistem Terdistribusi","Ubiquitous & Net-Centric Computing","Robotika",
									  "Rancangan Sistem Dijital","Teknologi Mobile"};
	
	public static void main(String[] args) throws IOException{
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(MataKuliah.class.getSimpleName() + ".csv"));
		for(int i = 0; i < amount; i++){
			writer.write(writeKode(i+1)+ "," + namaMataKuliah[i] + " , " + writeKode(createRandom(namaMataKuliah.length+1)) + "\n");
			writer.flush();
		}
		writer.close();
	}
	
	public static String writeKode(int x){
		
		String tmp = "" + x;
		
		if(x == 0){
			return "";
		}
		
		while(tmp.length() < 10){
			tmp = "0"+tmp;
		}
		
		return tmp;
	}
	
	public static int createRandom(int maxValue){
		int tmp = (int) Math.floor(maxValue * Math.random());
		return tmp;
	}
}