import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class Kelas_MK{
	
	static int amount = 30;
	static int jumlahMatakuliah = 40;
	
	static int kode = 0;
	static String[] tahun = {"2016","2017"};
	static String[] semester = {"1","2","3"};
	
	public static void main(String[] args) throws IOException{
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(Kelas_MK.class.getSimpleName() + ".csv"));
		for(int i = 0; i < amount; i++){
			writer.write(writeKode(i+1)+ "," + tahun[createRandom(tahun.length)] + "," + semester[createRandom(semester.length)]+ "," +
						 writeKode(createRandom(jumlahMatakuliah)) + "\n");
			writer.flush();
		}
		writer.close();
	}
	
	public static String writeKode(int x){
		
		String tmp = "" + x;
		
		if(x == 0){
			return "";
		}
		
		while(tmp.length() < 10){
			tmp = "0"+tmp;
		}
		
		return tmp;
	}
	
	public static int createRandom(int maxValue){
		int tmp = (int) Math.floor(maxValue * Math.random());
		return tmp;
	}
}