import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class Telepon{
	
	static int amount = 70;
	
	static int kode = 0;
	
	public static void main(String[] args) throws IOException{
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(Telepon.class.getSimpleName() + ".csv"));
		for(int i = 0; i < amount; i++){
			writer.write(writeKode(10,i+1) +","+ createTelepon() + "\n");
			writer.flush();
		}
		writer.close();
	}
	
	public static String writeKode(int max, int x){
		
		String tmp = "" + x;
		
		if(x == 0){
			return "";
		}
		
		while(tmp.length() < max){
			tmp = "0"+tmp;
		}
		
		return tmp;
	}
	
	public static int createRandom(int maxValue){
		int tmp = (int) Math.floor(maxValue * Math.random());
		return tmp;
	}
	
	public static String createTelepon(){
		String tmp = "0812";
		tmp += createRandom(1000000000);
		return tmp;
	}
}