import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;
public class Log{
	
	static int amount = 100;
	
	static int kode = 0;
	
	public static void main(String[] args) throws IOException{
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(Log.class.getSimpleName() + ".csv"));
	
		for (int i = 0; i < amount; i++) {
			writer.write(writeKode(10,i) + ","+ writeKode(10,createRandom(100)) +","+ writeKode(10,1+createRandom(70)) +","+ (1+createRandom(7)) + ","+(1+createRandom(4)) + "\n");
			writer.flush();
		}
		
		writer.close();
	}
	
	public static String writeKode(int max, int x){
		
		if(x == 0){
			x = 1; 
		}
		
		String tmp = "" + x;
		
		while(tmp.length() < max){
			tmp = "0"+tmp;
		}
		
		return tmp;
	}
	
	public static int createRandom(int maxValue){
		int tmp = (int) Math.floor(maxValue * Math.random());
		return tmp;
	}
	
}