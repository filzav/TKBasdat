import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class Lowongan{
	
	static int amount = 50;
	
	static int kode = 0;
	
	public static void main(String[] args) throws IOException{
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(Lowongan.class.getSimpleName() + ".csv"));
		for(int i = 0; i < amount; i++){
			writer.write(writeKode(10,i+1) + "," + writeKode(10,createRandom(30)) + "," + writeKode(10,createRandom(40)) + "," + 
						 createStatus() + "," + createJumlahAsisten() + "," + " " + "," + writeKode(20,createRandom(30)) + "\n");
			writer.flush();
		}
		writer.close();
	}
	
	public static String writeKode(int max, int x){
		
		if(x == 0){
			x = 1; 
		}
		
		String tmp = "" + x;
		
		while(tmp.length() < max){
			tmp = "0"+tmp;
		}
		
		return tmp;
	}
	
	public static int createRandom(int maxValue){
		int tmp = (int) Math.floor(maxValue * Math.random());
		return tmp;
	}
	
	public static boolean createStatus(){
		int tmp = createRandom(10);
		if(tmp <= 5){
			return false;
		}
		return true;
	}
	
	public static int createJumlahAsisten(){
		
		int tmp = 1;
	
		while(tmp % 5 != 0 && tmp % 3 != 0){
			tmp = createRandom(15);
		}
		
		return tmp;
	}
	
}