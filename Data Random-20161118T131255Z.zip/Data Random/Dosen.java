import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class Dosen{
	
	static int amount = 30;
	
	static int kode = 0;
	static String[] nama = {"Andi","Akari","Bella","Charlie","Dave","Ernie","Finn","Gerald","Hillary","Ivan","Jake","Karen","Kyoko","Lulu","Minh","Neil","Nozomi",
							"Oprah","Popuri","Quinn","Raisa","Seth","Tony","Ui","Vinny","Wanda","Xavier","Yogi","Zed","Zelda"};
							
	static String[] password = {"lebahganteng","peinakatsuki","gogogo","mimimi","akurapopo","desudesu","minnahappy","arararararagi","basdatlelah","haleltadsab"};
	static String[] email = {"@gmail.com", "@hotmail.com","@ymail.com"};
	
	static String[] fakultas = {"Fakultas Kedokteran","Fakultas Kedokteran Gigi","Fakultas Farmasi","Fakultas Kesehatan Masyarakat","Fakultas Ilmu Keperawatan", 
								"Fakultas Matematika dan Ilmu Pengetahuan Alam","Fakultas Teknik","Fakultas Ilmu Komputer", "Fakultas Hukum", "Fakultas Ekonomi dan Bisnis",
								"Fakultas Ilmu Pengetahuan Budaya","Fakultas Psikologi","Fakultas Ilmu Sosial dan Ilmu Politik","Fakultas Ilmu Administrasi"};
	
	static String[] universitas = {"UI","UGM","ITB","Gunadarma"};
	
	public static void main(String[] args) throws IOException{
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(Dosen.class.getSimpleName() + ".csv"));
		for(int i = 0; i < amount; i++){
			writer.write(writeKode(20,i+1) + "," + nama[i]+ "," + createUsername(nama[i]) + "," + password[createRandom(password.length)]+ "," +
						 createEmail(createUsername(nama[i]))+ "," + universitas[createRandom(universitas.length)] + "," + fakultas[createRandom(fakultas.length)] +"\n");
			writer.flush();
		}
		writer.close();
	}
	
	public static String writeKode(int max, int x){
		
		String tmp = "" + x;
		
		if(x == 0){
			return "";
		}
		
		while(tmp.length() < max){
			tmp = "0"+tmp;
		}
		
		return tmp;
	}
	
	public static int createRandom(int maxValue){
		int tmp = (int) Math.floor(maxValue * Math.random());
		return tmp;
	}
	
	public static String createUsername(String text){
		return text.toLowerCase();
	}
	
	public static String createEmail(String text){
		return text + email[createRandom(email.length)];
	}
}