import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Set;
import java.util.HashSet;

public class Lamaran{
	
	static int amount = 100;
	
	static int kode = 0;
	
	public static void main(String[] args) throws IOException{
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(Lamaran.class.getSimpleName() + ".csv"));
		Set<String> set = new HashSet<String>();
		
		int i = 0;
		
		while (set.size() < amount){
			set.add(writeKode(10,i)+","+writeKode(10,createRandom(70)));
			i++;
		}
		
		
		for (String s : set) {
			System.out.println(s);
			writer.write(s + "," + writeKode(10,createRandom(50))+"," + createRandom(4) + "," + createIPK() + "," +createRandom(10)+","+ writeKode(20,createRandom(30)) +"\n");
			writer.flush();
		}
		
		writer.close();
	}
	
	public static String writeKode(int max, int x){
		
		if(x == 0){
			x = 1; 
		}
		
		String tmp = "" + x;
		
		while(tmp.length() < max){
			tmp = "0"+tmp;
		}
		
		return tmp;
	}
	
	public static int createRandom(int maxValue){
		int tmp = (int) Math.floor(maxValue * Math.random());
		return tmp;
	}

	
	public static double createIPK(){
		
		double tmp = 3 + Math.random();
		
		if(tmp > 4){
			tmp = 4;
		}
		return tmp;
	}

	
}