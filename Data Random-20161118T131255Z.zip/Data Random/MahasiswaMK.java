import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Set;
import java.util.HashSet;

public class MahasiswaMK{
	
	static int amount = 150;
	
	public static void main(String[] args) throws IOException{
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(MahasiswaMK.class.getSimpleName() + ".csv"));
		
		Set<String> set = new HashSet<String>();
		
		while (set.size() < amount){
			set.add(writeKode(10,createRandom(70))+","+writeKode(10,createRandom(30)));
		}
		
		for (String s : set) {
			writer.write(s+","+createNilai()+"\n");
			writer.flush();
		}
		
	
		writer.close();
	}
	
	public static String writeKode(int max, int x){
		
		if(x == 0){
			x = 1;
		}
		
		String tmp = "" + x;
		
		while(tmp.length() < max){
			tmp = "0"+tmp;
		}
		
		return tmp;
	}
	
	public static int createRandom(int maxValue){
		int tmp = (int) Math.floor(maxValue * Math.random());
		return tmp;
	}
	
	public static int createNilai(){
		int tmp = 0;
		
		while(tmp < 65){
			tmp = createRandom(110); 
		}
		
		if(tmp > 100){
			tmp = 100;
		}
		
		return tmp;
	}
}